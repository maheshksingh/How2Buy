using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using AdaptiveCards;
using LuisBot.Cards;
using LuisBot.Dialogs;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;

namespace Microsoft.Bot.Sample.LuisBot
{
    // For more information about this template visit http://aka.ms/azurebots-csharp-luis
    [Serializable]
    public class BasicLuisDialog : LuisDialog<object>
    {
        private string userEmail = null;

        private static string QnA_endpointKey = "e2fa49c5-28b3-4d79-8e47-e88bec207915";
        private static string QnA_endpointDomain = "chitchatqna";
        private static string ChitChat_knowledgeBaseId = "991f02f6-95e3-4e25-8e7f-e5b281957b28";
        public ChitChatQnADialog ChitChat_QnAService = new ChitChatQnADialog("https://" + QnA_endpointDomain + ".azurewebsites.net", ChitChat_knowledgeBaseId, QnA_endpointKey);
        
        //public BasicLuisDialog() : base(new LuisService(new LuisModelAttribute(
        //    ConfigurationManager.AppSettings["LuisAppId"], 
        //    ConfigurationManager.AppSettings["LuisAPIKey"], 
        //    domain: ConfigurationManager.AppSettings["LuisAPIHostName"])))
        //{
        //}
        public BasicLuisDialog(string _uEmail) : base(new LuisService(new LuisModelAttribute(
            "44e0a82c-4e8d-4d25-9ed2-a42e749f131c",
            "90b712326ca644198f0bd3392a0d6b84",
            domain: "westus.api.cognitive.microsoft.com")))
        {
            this.userEmail = _uEmail;
        }

        [LuisIntent("None")]
        public async Task NoneIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            await this.NoneIntentResult(context, activity, result);
        }
        private async Task NoneIntentResult(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;
            string response = null;
            try
            {
                var chitchatQnAanswer = await ChitChat_QnAService.GetAnswer(result.Query);
                response = chitchatQnAanswer.ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (response == null || response == "None")
            {
                response = "Opps! Seems I dont have any information regarding this query. \nPlease write to Support.ipsbot@volvo.com for the same.";
            }

            if (_activity.Locale != "en")
            {
                response = await this.Translate(response, _activity.Locale);
            }
            
            await context.PostAsync(response);
            await this.SendEmail(_activity.Text, this.userEmail);
            context.Done<string>("DoneFromLuisDialog");
        }

        [LuisIntent("Greeting")]
        public async Task GreetingIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;
            if (result.TopScoringIntent.Score > 0.5)
            {
                string response = null;
                if (_activity.Locale != "en")
                {
                    response = await this.Translate("Hello there! Greetings of the day!! How may I assist you today?", _activity.Locale);
                }
                else
                {
                    response = "Hello there! Greetings of the day!! How may I assist you today?";
                }
                await context.PostAsync(response);
                context.Done<string>("DoneFromLuisDialog");
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("Cancel")]
        public async Task CancelIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;
            if (result.TopScoringIntent.Score > 0.5)
            {
                string response = null;
                if (_activity.Locale != "en")
                {
                    response = await this.Translate("OK. I will stop. Hope to talk to you soon", _activity.Locale);
                }
                else
                {
                    response = "OK. I will stop. Hope to talk to you soon";
                }
                await context.PostAsync(response);
                context.Done<string>("DoneFromLuisDialog");
               
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("Help")]
        public async Task HelpIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;
            if (result.TopScoringIntent.Score > 0.5)
            {
                string response = null;
                if (_activity.Locale != "en")
                {
                    response = await this.Translate("Sure! I can help you with the follwing things", _activity.Locale);
                }
                else
                {
                    response = "Sure! I can help you with the follwing things";
                }

                var replyWithCard = context.MakeMessage();
                replyWithCard.Text = response;
                AdaptiveCard card = new AdaptiveCard();
                CardHelper cardHelper = new CardHelper();
                card = await cardHelper.GetProactiveCard(_activity.Locale);
                Connector.Attachment attachment = new Connector.Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                replyWithCard.Attachments.Add(attachment);
                await context.PostAsync(replyWithCard);
                context.Done<string>("DoneFromLuisDialog");
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }

        }


        [LuisIntent("ToolsforRequesters")]
        public async Task ToolsForRequestersIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;

            var replyTyping = context.MakeMessage();
            replyTyping.Type = ActivityTypes.Typing;

            var reply = context.MakeMessage();

            if (result.TopScoringIntent.Score > 0.5)
            {
                AdaptiveCard card = new AdaptiveCard();
                if (_activity.Locale != "en")
                {
                    if (result.Query.ToUpper().Contains("EBD"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[EBD](http://eprocure.nap.volvo.net/site/)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else if (result.Query.ToUpper().Contains("GPS"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[GPS](http://teamplace.volvo.com/sites/PUsytemsAP/GPS/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else if (result.Query.ToUpper().Contains("VESA"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[VESA](https://teamplace.volvo.com/sites/nap-support/esourcing/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else if (result.Query.ToUpper().Contains("SURPLUS"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[Surplus Portal](https://teamplace.volvo.com/sites/nap-mro/sass/fr/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else if (result.Query.ToUpper().Contains("Fieldglass"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[SAP VMS Fieldglass](https://www.fieldglass.eu/login.jsp?message=error.sso.notAuthorized)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[EBD](http://eprocure.nap.volvo.net/site/)",
                            Weight = TextWeight.Bolder
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[GPS](http://teamplace.volvo.com/sites/PUsytemsAP/GPS/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[VESA](https://teamplace.volvo.com/sites/nap-support/esourcing/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[Surplus Portal](https://teamplace.volvo.com/sites/nap-mro/sass/fr/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[SAP VMS Fieldglass](https://www.fieldglass.eu/login.jsp?message=error.sso.notAuthorized)",
                            Weight = TextWeight.Bolder
                        });


                    }

                    Connector.Attachment attachment = new Connector.Attachment()
                    {
                        Content = card,
                        ContentType = AdaptiveCard.ContentType
                    };
                    reply.Text = await this.Translate("Please find the link :", _activity.Locale);
                    reply.Attachments.Add(attachment);
                }
                else
                {
                    if (result.Query.ToUpper().Contains("EBD"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[EBD](http://eprocure.nap.volvo.net/site/)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else if (result.Query.ToUpper().Contains("GPS"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[GPS](http://teamplace.volvo.com/sites/PUsytemsAP/GPS/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else if (result.Query.ToUpper().Contains("VESA"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[VESA](https://teamplace.volvo.com/sites/nap-support/esourcing/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else if (result.Query.ToUpper().Contains("SURPLUS"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[Surplus Portal](https://teamplace.volvo.com/sites/nap-mro/sass/fr/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else if (result.Query.ToUpper().Contains("Fieldglass"))
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[SAP VMS Fieldglass](https://www.fieldglass.eu/login.jsp?message=error.sso.notAuthorized)",
                            Weight = TextWeight.Bolder
                        });
                    }
                    else
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[EBD](http://eprocure.nap.volvo.net/site/)",
                            Weight = TextWeight.Bolder
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[GPS](http://teamplace.volvo.com/sites/PUsytemsAP/GPS/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[VESA](https://teamplace.volvo.com/sites/nap-support/esourcing/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[Surplus Portal](https://teamplace.volvo.com/sites/nap-mro/sass/fr/default.aspx)",
                            Weight = TextWeight.Bolder
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "[SAP VMS Fieldglass](https://www.fieldglass.eu/login.jsp?message=error.sso.notAuthorized)",
                            Weight = TextWeight.Bolder
                        });


                    }

                    Connector.Attachment attachment = new Connector.Attachment()
                    {
                        Content = card,
                        ContentType = AdaptiveCard.ContentType
                    };
                    reply.Text = "Please find the link :";
                    reply.Attachments.Add(attachment);
                }

                await context.PostAsync(replyTyping);
                await Task.Delay(2000);
                await context.PostAsync(replyTyping);
                await context.PostAsync(reply);
                context.Done<string>("DoneFromLuisDialog");
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("Acknowledgement")]
        public async Task AcknowledgementIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;

            if (result.TopScoringIntent.Score > 0.5)
            {
                string response = null;
                if (_activity.Locale != "en")
                {
                    response = await this.Translate("Happy to help! Thank you for contacting IPS Chat Bot", _activity.Locale);
                }
                else
                {
                    response = "Happy to help! Thank you for contacting IPS Chat Bot";
                }
                await context.PostAsync(response);
                context.Wait(MessageReceived);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("IPS")]
        public async Task IPSIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.5)
            {
                await this.IPSIntentResult(context, activity, result);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("QnA")]
        public async Task QnAIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.3)
            {
                await this.QnAIntentResult(context, activity, result);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
            

        }

        [LuisIntent("GenericQuestion")]
        public async Task GenericQuestionIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;
            AdaptiveCard card = new AdaptiveCard();

            if (result.TopScoringIntent.Score > 0.5)
            {
                if (result.Query.ToLower().Contains("how to buy") || result.Query.ToLower().Contains("h2b") || result.Query.ToLower().Contains("how2buy") || result.Query.ToLower().Contains("how2buy"))
                {
                    if (_activity.Locale != "en")
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = await this.Translate("What is How2Buy ?", _activity.Locale),
                            Weight = TextWeight.Bolder,
                            Wrap = true
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = await this.Translate("- It is an application that provides contact details, " +
                            "purchasing policies  and all other related information for different segments and commodities in IPS portfolio.", _activity.Locale),
                            Wrap = true
                        });
                    }
                    else
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "What is How2Buy ?",
                            Weight = TextWeight.Bolder,
                            Wrap = true
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "- It is an application that provides contact details, " +
                            "purchasing policies  and all other related information for different segments and commodities in IPS portfolio.",
                            Wrap = true
                        });
                    }
                    
                }
                else if (result.Query.ToLower().Contains("ips"))
                {
                    if (_activity.Locale != "en")
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = await this.Translate("What is IPS+ ?", _activity.Locale),
                            Weight = TextWeight.Bolder,
                            Wrap = true
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = await this.Translate("- It is a one stop shop for finding all links related to Indirect Products and Services portfolio.", _activity.Locale),
                            Wrap = true
                        });
                    }
                    else
                    {
                        card.Body.Add(new TextBlock()
                        {
                            Text = "What is IPS+ ?",
                            Weight = TextWeight.Bolder,
                            Wrap = true
                        });
                        card.Body.Add(new TextBlock()
                        {
                            Text = "- It is a one stop shop for finding all links related to Indirect Products and Services portfolio.",
                            Wrap = true
                        });
                    }
                    
                }
                Connector.Attachment attachment = new Connector.Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                var reply = context.MakeMessage();
                reply.Attachments.Add(attachment);
                await context.PostAsync(reply);
                context.Wait(MessageReceived);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }

        }

        private async Task IPSIntentResult(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;
            context.Call(new IPSDialog(result.Query.ToString(), this.userEmail, _activity.Locale), this.ResumeAfterNextDialog);
        }

        private async Task QnAIntentResult(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var _activity = await activity as Activity;
            string query = result.Query.ToString();
            string country = null;
            foreach (var item in result.Entities)
            {
                if (item.Type == "Country")
                {
                    country = item.Entity.ToString();
                }
            }
                
            context.Call(new HowToBuyDialog(query, country, this.userEmail, _activity.Locale), this.ResumeAfterNextDialog);
        }

        private async Task ResumeAfterNextDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Wait(MessageReceived);
        }

        private async Task SendEmail(string query, string toEmail)
        {

            StringBuilder strHtml = new StringBuilder();

            strHtml.Append("</head>\n");
            strHtml.Append("<body  bgcolor=\"#ffffff\">\n");

            strHtml.Append("<table style=\"font-family:calibri;\" width=\"100%\" height=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n");
            strHtml.Append("<tr>\n");
            //strHtml.Append("<td class=\"bluebackground\">&nbsp;</td>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("<div class=\"header2\">\n");
            strHtml.Append("<p style=\"border-style:solid; border-color:#566D7E;\">");
            strHtml.Append("<b>");
            strHtml.Append("Regarding Un-Answered Queries from BOB \n");
            strHtml.Append("</b>");
            strHtml.Append("</div>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("<b>");
            strHtml.Append("Following is the Unanswered Query: ");
            strHtml.Append("</b>");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("Query: " + query);
            strHtml.Append("</td>\n");

            strHtml.Append("<td>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");

            strHtml.Append("<td>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td>\n");
            strHtml.Append("<br></br>\n");
            strHtml.Append("<br></br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");


            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("Regards,");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td>\n");
            strHtml.Append("BOB - The IPS Chatbot");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("</table>\n");
            strHtml.Append("</body>\n");
            strHtml.Append("</html>\n");



            string msgSenderEmail = string.Empty;
            string msgRecipient = string.Empty;
            string smtpServer = string.Empty;

            MailMessage mail = new MailMessage();

            msgSenderEmail = "Support.ipsbot@volvo.com";
            msgRecipient = toEmail;
            smtpServer = "mailgot.it.volvo.com";
            mail.From = new MailAddress(msgSenderEmail);
            mail.To.Add(msgRecipient);
            mail.Subject = "Reg: BOB Unresolved Query";
            mail.Body = strHtml.ToString();
            mail.IsBodyHtml = true;

            SmtpClient SmtpServer = new SmtpClient(smtpServer);

            SmtpServer.Send(mail);

        }

        private async Task<string> Translate(string text, string toLang)
        {
            string result = null;
            var translatorClient = new TranslatorService.TranslatorClient("8c51979522cf43c38d67847add69b2d9");
            var languageDetected = translatorClient.DetectLanguageAsync(text);
            var trasnlatedText = await translatorClient.TranslateAsync(text, toLang);
            result = trasnlatedText.Translation.Text;
            return result;
        }
    }
}