﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AdaptiveCards;
using LuisBot;
using LuisBot.SearchHelper;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;

namespace Microsoft.Bot.Sample.LuisBot
{
    [Serializable]
    public class IPSDialog : IDialog<object>
    {
        private string userEmail = null;
        private string query;
        private int repeatCounter = 0;
        private string lang = null;
        public IPSDialog(string _query, string _uEmail, string _lang)
        {
            this.userEmail = _uEmail;
            this.query = _query;
            this.lang = _lang;
        }

        public async Task StartAsync(IDialogContext context)
        {
            List<Connector.Attachment> attachments = new List<Connector.Attachment>();
            attachments = await SearchDataAsync(this.query);

            if (attachments.Count > 0)
            {
                if(this.lang != "en")
                {
                    var reply = context.MakeMessage();
                    reply.Text = await this.Translate("Here is your search results...", this.lang);
                    reply.Attachments = attachments;
                    reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                    await context.PostAsync(reply);

                    var replyNext = context.MakeMessage();
                    replyNext.Text = await this.Translate("Does this help ?", this.lang);
                    CardAction actionYes = new CardAction()
                    {
                        DisplayText = await this.Translate("YES", this.lang),
                        Text = await this.Translate("YES", this.lang),
                        Value = await this.Translate("YES", this.lang),
                        Title = await this.Translate("YES", this.lang),
                        Type = ActionTypes.ImBack
                    };
                    CardAction actionNo = new CardAction()
                    {
                        DisplayText = await this.Translate("NO", this.lang),
                        Text = await this.Translate("NO", this.lang),
                        Value = await this.Translate("NO", this.lang),
                        Title = await this.Translate("NO", this.lang),
                        Type = ActionTypes.ImBack
                    };
                    List<CardAction> cardActions = new List<CardAction>();
                    cardActions.Add(actionYes);
                    cardActions.Add(actionNo);
                    SuggestedActions suggestedActions = new SuggestedActions()
                    {
                        Actions = cardActions
                    };
                    replyNext.SuggestedActions = suggestedActions;
                    await context.PostAsync(replyNext);
                }
                else
                {
                    var reply = context.MakeMessage();
                    reply.Text = "Here is your search results...";
                    reply.Attachments = attachments;
                    reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                    await context.PostAsync(reply);

                    var replyNext = context.MakeMessage();
                    replyNext.Text = "Does this help ?";
                    CardAction actionYes = new CardAction()
                    {
                        DisplayText = "YES",
                        Text = "YES",
                        Value = "YES",
                        Title = "YES",
                        Type = ActionTypes.ImBack
                    };
                    CardAction actionNo = new CardAction()
                    {
                        DisplayText = "NO",
                        Text = "NO",
                        Value = "NO",
                        Title = "NO",
                        Type = ActionTypes.ImBack
                    };
                    List<CardAction> cardActions = new List<CardAction>();
                    cardActions.Add(actionYes);
                    cardActions.Add(actionNo);
                    SuggestedActions suggestedActions = new SuggestedActions()
                    {
                        Actions = cardActions
                    };
                    replyNext.SuggestedActions = suggestedActions;
                    await context.PostAsync(replyNext);
                }
                

                context.Wait(this.CheckIfResultWorked);
            }
            else
            {
                await this.SendEmail(this.query, this.userEmail);
                if (this.lang != "en")
                {
                    await context.PostAsync(await this.Translate("Sorry! Not able to find any relevant data. " +
                   "I have registered your query to the support team. They will get back to you shortly", this.lang));
                }
                else
                {
                    await context.PostAsync("Sorry! Not able to find any relevant data. " +
                   "I have registered your query to the support team. They will get back to you shortly");
                }
                context.Done<string>("DoneFromHowToBuyDialog");
            }
        }

        private async Task CheckIfResultWorked(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;

            var messageText = await this.Translate(message.Text, "en");

            if (messageText.ToUpper().Contains("YES"))
            {
                await context.PostAsync("Great! Happy to help.");
                context.Done<string>("DoneFromIPSDialog");
            }
            else if (messageText.ToUpper().Contains("NO"))
            {
                this.repeatCounter++;
                if (this.repeatCounter < 2)
                {
                    
                    List<Connector.Attachment> attachments = new List<Connector.Attachment>();
                    attachments = await SearchMoreDataAsync(this.query);
                    if (attachments.Count > 0)
                    {
                        if(this.lang != "en")
                        {
                            await context.PostAsync(await this.Translate("Ok then, let me show you some more results.", this.lang));
                            var reply = context.MakeMessage();
                            reply.Text = await this.Translate("Here are some more search results...", this.lang);
                            reply.Attachments = attachments;
                            reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                            await context.PostAsync(reply);

                            var replyNext = context.MakeMessage();
                            replyNext.Text = await this.Translate("Does it help ?", this.lang);
                            CardAction actionYes = new CardAction()
                            {
                                DisplayText = await this.Translate("YES", this.lang),
                                Text = await this.Translate("YES", this.lang),
                                Value = await this.Translate("YES", this.lang),
                                Title = await this.Translate("YES", this.lang),
                                Type = ActionTypes.ImBack
                            };
                            CardAction actionNo = new CardAction()
                            {
                                DisplayText = await this.Translate("NO", this.lang),
                                Text = await this.Translate("NO", this.lang),
                                Value = await this.Translate("NO", this.lang),
                                Title = await this.Translate("NO", this.lang),
                                Type = ActionTypes.ImBack
                            };
                            List<CardAction> cardActions = new List<CardAction>();
                            cardActions.Add(actionYes);
                            cardActions.Add(actionNo);
                            SuggestedActions suggestedActions = new SuggestedActions()
                            {
                                Actions = cardActions
                            };
                            replyNext.SuggestedActions = suggestedActions;
                            await context.PostAsync(replyNext);
                        }
                        else
                        {
                            await context.PostAsync("Ok then, let me show you some more results.");
                            var reply = context.MakeMessage();
                            reply.Text = "Here are some more search results...";
                            reply.Attachments = attachments;
                            reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                            await context.PostAsync(reply);

                            var replyNext = context.MakeMessage();
                            replyNext.Text = "Does this help ?";
                            CardAction actionYes = new CardAction()
                            {
                                DisplayText = "YES",
                                Text = "YES",
                                Value = "YES",
                                Title = "YES",
                                Type = ActionTypes.ImBack
                            };
                            CardAction actionNo = new CardAction()
                            {
                                DisplayText = "NO",
                                Text = "NO",
                                Value = "NO",
                                Title = "NO",
                                Type = ActionTypes.ImBack
                            };
                            List<CardAction> cardActions = new List<CardAction>();
                            cardActions.Add(actionYes);
                            cardActions.Add(actionNo);
                            SuggestedActions suggestedActions = new SuggestedActions()
                            {
                                Actions = cardActions
                            };
                            replyNext.SuggestedActions = suggestedActions;
                            await context.PostAsync(replyNext);
                        }
                        

                        context.Wait(this.CheckIfResultWorked);
                    }
                    else
                    {
                        await this.SendEmail(this.query, this.userEmail);
                        if (this.lang != "en")
                        {
                            await context.PostAsync(await this.Translate("Sorry! Not able to find any more relevant data. " +
                           "I have registered your query to the support team. They will get back to you shortly", this.lang));
                        }
                        else
                        {
                            await context.PostAsync("Sorry! Not able to find any more relevant data. " +
                           "I have registered your query to the support team. They will get back to you shortly");
                        }
                        context.Done<string>("DoneFromHowToBuyDialog");
                    }
                }
                else
                {
                    await this.SendEmail(this.query, this.userEmail);
                    if (this.lang != "en")
                    {
                        await context.PostAsync(await this.Translate("Sorry to hear that. I have registered your query " +
                        "with our support desk. They will get back to you shortly.", this.lang));
                    }
                    else
                    {
                        await context.PostAsync("Sorry to hear that. I have registered your query " +
                        "with our support desk. They will get back to you shortly.");
                    }
                    context.Done<string>("DoneFromHowToBuyDialog");
                }

            }
            else
            {
                var translatorClient = new TranslatorService.TranslatorClient("8c51979522cf43c38d67847add69b2d9");
                var trasnlatedText = await translatorClient.TranslateAsync(message.Text, "en");

                var newMessage = context.MakeMessage();
                newMessage.Text = trasnlatedText.Translation.Text;
                newMessage.Locale = trasnlatedText.DetectedLanguage.Language;
                await context.Forward(new BasicLuisDialog(this.userEmail), this.ResumeAfterNextDialog, newMessage, CancellationToken.None);
            }
        }

        private async Task ResumeAfterNextDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Done<string>("DoneFromIPSDialog");
        }

        private async Task<List<Connector.Attachment>> SearchDataAsync(string _query)
        {
            SearchHelper helper = new SearchHelper();
            List<IPSSearchValue> ipsSearchResult = new List<IPSSearchValue>();
            ipsSearchResult = helper.IPSSearchData(_query);

            List<Connector.Attachment> attachments = new List<Connector.Attachment>();
            int count = 0;
            if (ipsSearchResult.Count > 5)
            {
                count = 5;
            }
            else
            {
                count = ipsSearchResult.Count;
            }
            for (int i = 0; i < count; i++)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new TextBlock()
                {
                    Text = "Category : " + ipsSearchResult[i].Category
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "SubCategory : " + ipsSearchResult[i].SubCategory
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "Application : " + ipsSearchResult[i].Application
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "[Click Here](" + ipsSearchResult[i].Links + ")"
                });

                Connector.Attachment attachment = new Connector.Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                attachments.Add(attachment);

            }

            return attachments;
        }

        private async Task<List<Connector.Attachment>> SearchMoreDataAsync(string _query)
        {
            SearchHelper helper = new SearchHelper();
            List<IPSSearchValue> ipsSearchResult = new List<IPSSearchValue>();
            ipsSearchResult = helper.IPSSearchData(_query);

            List<Connector.Attachment> attachments = new List<Connector.Attachment>();
            int limit = 0;
            if(ipsSearchResult.Count > 10)
            {
                limit = 10;
            }
            else
            {
                limit = ipsSearchResult.Count;
            }
            for (int i = 5; i < limit; i++)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new TextBlock()
                {
                    Text = "Category : " + ipsSearchResult[i].Category
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "SubCategory : " + ipsSearchResult[i].SubCategory
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "Application : " + ipsSearchResult[i].Application
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "[Click Here](" + ipsSearchResult[i].Links + ")"
                });

                Connector.Attachment attachment = new Connector.Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                attachments.Add(attachment);

            }
            return attachments;
        }

        private async Task SendEmail(string query, string toEmail)
        {

            StringBuilder strHtml = new StringBuilder();

            strHtml.Append("</head>\n");
            strHtml.Append("<body  bgcolor=\"#ffffff\">\n");

            strHtml.Append("<table style=\"font-family:calibri;\" width=\"100%\" height=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n");
            strHtml.Append("<tr>\n");
            //strHtml.Append("<td class=\"bluebackground\">&nbsp;</td>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("<div class=\"header2\">\n");
            strHtml.Append("<p style=\"border-style:solid; border-color:#566D7E;\">");
            strHtml.Append("<b>");
            strHtml.Append("Regarding Un-Answered Queries from BOB \n");
            strHtml.Append("</b>");
            strHtml.Append("</div>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("<b>");
            strHtml.Append("Following is the Unanswered Query: ");
            strHtml.Append("</b>");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("Query: " + query);
            strHtml.Append("</td>\n");

            strHtml.Append("<td>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");

            strHtml.Append("<td>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td>\n");
            strHtml.Append("<br></br>\n");
            strHtml.Append("<br></br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");


            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("Regards,");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td>\n");
            strHtml.Append("BOB - The IPS Chatbot");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("</table>\n");
            strHtml.Append("</body>\n");
            strHtml.Append("</html>\n");



            string msgSenderEmail = string.Empty;
            string msgRecipient = string.Empty;
            string smtpServer = string.Empty;

            MailMessage mail = new MailMessage();

            msgSenderEmail = "Support.ipsbot@volvo.com";
            msgRecipient = toEmail;
            smtpServer = "mailgot.it.volvo.com";
            mail.From = new MailAddress(msgSenderEmail);
            mail.To.Add(msgRecipient);
            mail.Subject = "Reg: BOB Unresolved Query";
            mail.Body = strHtml.ToString();
            mail.IsBodyHtml = true;

            SmtpClient SmtpServer = new SmtpClient(smtpServer);

            SmtpServer.Send(mail);

        }

        private async Task<string> Translate(string text, string toLang)
        {
            string result = null;
            var translatorClient = new TranslatorService.TranslatorClient("8c51979522cf43c38d67847add69b2d9");
            var languageDetected = translatorClient.DetectLanguageAsync(text);
            var trasnlatedText = await translatorClient.TranslateAsync(text, toLang);
            result = trasnlatedText.Translation.Text;
            return result;
        }
    }
}