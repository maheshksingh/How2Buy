﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Sample.LuisBot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using TranslatorService.Models;

namespace LuisBot.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        private string userEmail = null;
        public RootDialog(string _userEmail)
        {
            this.userEmail = _userEmail;
        }
        public async Task StartAsync(IDialogContext context)
        {
            context.Wait(this.MessageReceivedAsync);
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result as Activity;

            if (!message.Text.ToUpper().Contains("EBD"))
            {
                var translatorClient = new TranslatorService.TranslatorClient("8c51979522cf43c38d67847add69b2d9");

                var trasnlatedText = await translatorClient.TranslateAsync(message.Text, "en");
                message.Locale = trasnlatedText.DetectedLanguage.Language;
                message.Text = trasnlatedText.Translation.Text;
            }

            await context.Forward(new BasicLuisDialog(this.userEmail), this.ResumeAfterNextDialog, message, CancellationToken.None);
        }

        private async Task ResumeAfterNextDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Done<string>("DoneFromRootDialog");
        }
    }
}