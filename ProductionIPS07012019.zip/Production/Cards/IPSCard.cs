﻿using AdaptiveCards;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LuisBot.Cards
{
    [Serializable]
    public partial class CardHelper
    {
        public AdaptiveCard GetIPSMainCard()
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new TextBlock()
            {
                Text = "Here are the IPS+ links below:",
                Weight = TextWeight.Bolder,
                Size = TextSize.Medium
            });
            card.Body.Add(new TextBlock()
            {
                Text = "[Develop & Update Procurement Strategy](https://teamplace.volvo.com/sites/gttpubusinessandstrategicoffice/IPS%20Excellence/IPS%20PLUS%20PORTAL/SiteAssets/IPS%20Site%20Pages/developupdate.aspx)",
                Weight = TextWeight.Bolder
            });
            card.Body.Add(new TextBlock()
            {
                Text = "[Manage Supplier Relationship/SRM](https://teamplace.volvo.com/sites/gttpubusinessandstrategicoffice/IPS%20Excellence/IPS%20PLUS%20PORTAL/SiteAssets/IPS%20Site%20Pages/managersupplier.aspx)",
                Weight = TextWeight.Bolder
            });
            card.Body.Add(new TextBlock()
            {
                Text = "[Administrate Supplier Data & Mitigate Payment](https://teamplace.volvo.com/sites/gttpubusinessandstrategicoffice/IPS%20Excellence/IPS%20PLUS%20PORTAL/SiteAssets/IPS%20Site%20Pages/administration.aspx)",
                Weight = TextWeight.Bolder
            });
            card.Body.Add(new TextBlock()
            {
                Text = "[Order and Receive Indirect Products or Services](https://teamplace.volvo.com/sites/gttpubusinessandstrategicoffice/IPS%20Excellence/IPS%20PLUS%20PORTAL/SiteAssets/IPS%20Site%20Pages/order.aspx)",
                Weight = TextWeight.Bolder
            });
            card.Body.Add(new TextBlock()
            {
                Text = "[Purchasing Portfolio Management](https://teamplace.volvo.com/sites/gttpubusinessandstrategicoffice/IPS%20Excellence/IPS%20PLUS%20PORTAL/SiteAssets/IPS%20Site%20Pages/purchasing.aspx)",
                Weight = TextWeight.Bolder
            });

            return card;
        }

        public AdaptiveCard GetCategory(List<string> list)
        {
            AdaptiveCard card = new AdaptiveCard();
            List<Choice> adaptiveChoicesCommodity = new List<Choice>();
            foreach (var item in list)
            {
                adaptiveChoicesCommodity.Add(new Choice()
                {
                    Title = item.ToString(),
                    Value = item.ToString(),
                });
            }
            card.Body.Add(new TextBlock()
            {
                Text = "Please selet the Main Area",
                Weight = TextWeight.Bolder,
                Size = TextSize.Normal
            });
            card.Body.Add(new ChoiceSet()
            {
                Id = "Category",
                Style = ChoiceInputStyle.Compact,
                IsMultiSelect = false,
                Choices = adaptiveChoicesCommodity
            });
            card.Actions.Add(new SubmitAction()
            {
                Title = "GO",
                DataJson = "{\"Type\": \"GetCategory\" }"
            });


            return card;
        }

        public AdaptiveCard GetSubCategory(List<string> list, string _category)
        {
            AdaptiveCard card = new AdaptiveCard();
            List<Choice> adaptiveChoicesCommodity = new List<Choice>();
            foreach (var item in list)
            {
                adaptiveChoicesCommodity.Add(new Choice()
                {
                    Title = item.ToString(),
                    Value = item.ToString(),
                });
            }
            card.Body.Add(new TextBlock()
            {
                Text = "Please selet the Category for " + _category,
                Weight = TextWeight.Bolder,
                Size = TextSize.Normal
            });
            card.Body.Add(new ChoiceSet()
            {
                Id = "SubCategory",
                Style = ChoiceInputStyle.Compact,
                IsMultiSelect = false,
                Choices = adaptiveChoicesCommodity
            });
            card.Actions.Add(new SubmitAction()
            {
                Title = "GO",
                DataJson = "{\"Type\": \"GetSubCategory\" }"
            });


            return card;
        }

        public AdaptiveCard GetApplications(List<string> list, string _mainArea, string _subCategory)
        {
            AdaptiveCard card = new AdaptiveCard();
            List<Choice> adaptiveChoicesCommodity = new List<Choice>();
            foreach (var item in list)
            {
                adaptiveChoicesCommodity.Add(new Choice()
                {
                    Title = item.ToString(),
                    Value = item.ToString(),
                });
            }
            card.Body.Add(new TextBlock()
            {
                Text = "Please selet the Category for " + _mainArea,
                Weight = TextWeight.Bolder,
                Size = TextSize.Normal
            });
            card.Body.Add(new ChoiceSet()
            {
                Id = "Application",
                Style = ChoiceInputStyle.Compact,
                IsMultiSelect = false,
                Choices = adaptiveChoicesCommodity
            });
            card.Actions.Add(new SubmitAction()
            {
                Title = "GO",
                DataJson = "{\"Type\": \"GetApplication\" }"
            });


            return card;
        }

    }
}