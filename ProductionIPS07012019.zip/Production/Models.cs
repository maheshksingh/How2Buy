﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LuisBot
{
    public class H2BSearchValue
    {
        public double searchscore { get; set; }
        public string Id { get; set; }
        public string Country { get; set; }
        public string IPS_COMMODITY { get; set; }
        public string SEGMENT { get; set; }
        public string Link { get; set; }
        public string Tags { get; set; }
    }


    public class IPSSearchValue
    {
        public double searchscore { get; set; }
        public string ID { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string Application { get; set; }
        public string Links { get; set; }
        public string Tags { get; set; }
    }


}