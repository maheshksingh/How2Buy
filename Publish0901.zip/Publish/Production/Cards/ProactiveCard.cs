﻿using AdaptiveCards;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace LuisBot.Cards
{
    public partial class CardHelper
    {
        public async Task<AdaptiveCard> GetProactiveCard(string lang)
        {
            AdaptiveCard card = new AdaptiveCard();
            if (lang != "en")
            {
                card.Actions.Add(new SubmitAction()
                {
                    Data = await this.Translate("How2Buy", lang),
                    Title = await this.Translate("HOW2BUY(Quick Search)", lang)
                });
                card.Body.Add(new TextBlock()
                {
                    Text = await this.Translate("How2Buy", lang),
                    Weight = TextWeight.Bolder,
                    Size = TextSize.Medium,
                    Wrap = true
                });
                card.Body.Add(new TextBlock()
                {
                    Text = await this.Translate("- It is an application that provides contact details, " +
                    "purchasing policies  and all other related information for different segments and commodities in IPS portfolio.", lang),
                    Wrap = true
                });
                card.Actions.Add(new SubmitAction()
                {
                    Data = await this.Translate("IPS+", lang),
                    Title = await this.Translate("IPS+", lang)
                });
                card.Body.Add(new TextBlock()
                {
                    Text = await this.Translate("IPS+", lang),
                    Weight = TextWeight.Bolder,
                    Size = TextSize.Medium,
                    Wrap = true
                });
                card.Body.Add(new TextBlock()
                {
                    Text = await this.Translate("- It is a one stop shop for finding all links related to Indirect Products and Services portfolio.", lang),
                    Wrap = true
                });
            }
            else
            {
                card.Actions.Add(new SubmitAction()
                {
                    Data = "How2Buy",
                    Title = "HOW2BUY(Quick Search)"
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "How2Buy",
                    Weight = TextWeight.Bolder,
                    Size = TextSize.Medium,
                    Wrap = true
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "- It is an application that provides contact details, " +
                    "purchasing policies  and all other related information for different segments and commodities in IPS portfolio.",
                    Wrap = true
                });
                card.Actions.Add(new SubmitAction()
                {
                    Data = "IPS+",
                    Title = "IPS+"
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "IPS+",
                    Weight = TextWeight.Bolder,
                    Size = TextSize.Medium,
                    Wrap = true
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "- It is a one stop shop for finding all links related to Indirect Products and Services portfolio.",
                    Wrap = true
                });
            }
            

            return card;
        }

        private async Task<string> Translate(string text, string toLang)
        {
            string result = null;
            var translatorClient = new TranslatorService.TranslatorClient("8c51979522cf43c38d67847add69b2d9");
            var languageDetected = translatorClient.DetectLanguageAsync(text);
            var trasnlatedText = await translatorClient.TranslateAsync(text, toLang);
            result = trasnlatedText.Translation.Text;
            return result;
        }
    }
}