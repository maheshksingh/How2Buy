﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using AdaptiveCards;
using LuisBot;
using LuisBot.SearchHelper;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;

namespace Microsoft.Bot.Sample.LuisBot
{
    [Serializable]
    public class IPSDialog : IDialog<object>
    {
        private string userEmail = null;
        private string query;
        private int repeatCounter = 0;

        public IPSDialog(string _query, string _uEmail)
        {
            this.userEmail = _uEmail;
            this.query = _query;
        }

        public async Task StartAsync(IDialogContext context)
        {
            List<Attachment> attachments = new List<Attachment>();
            attachments = await SearchDataAsync(this.query);

            if (attachments.Count > 0)
            {
                var reply = context.MakeMessage();
                reply.Text = "Here is your search results...";
                reply.Attachments = attachments;
                reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                await context.PostAsync(reply);

                var replyNext = context.MakeMessage();
                replyNext.Text = "Does this help ?";
                CardAction actionYes = new CardAction()
                {
                    DisplayText = "YES",
                    Text = "YES",
                    Value = "YES",
                    Title = "YES",
                    Type = ActionTypes.ImBack
                };
                CardAction actionNo = new CardAction()
                {
                    DisplayText = "NO",
                    Text = "NO",
                    Value = "NO",
                    Title = "NO",
                    Type = ActionTypes.ImBack
                };
                List<CardAction> cardActions = new List<CardAction>();
                cardActions.Add(actionYes);
                cardActions.Add(actionNo);
                SuggestedActions suggestedActions = new SuggestedActions()
                {
                    Actions = cardActions
                };
                replyNext.SuggestedActions = suggestedActions;
                await context.PostAsync(replyNext);

                context.Wait(this.CheckIfResultWorked);
            }
            else
            {
                await context.PostAsync("Sorry! Not able to find any relevant data. I have registered your query to the support team. They will get back to you shortly");
                context.Done<string>("DoneFromIPSDialog");
            }
        }


        private async Task CheckIfResultWorked(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;
            if (message.Text == "YES")
            {
                await context.PostAsync("Great! Happy to help.");
                context.Done<string>("DoneFromIPSDialog");
            }
            else if (message.Text == "NO")
            {
                this.repeatCounter++;
                if (this.repeatCounter < 2)
                {
                    await context.PostAsync("Ok then, let me show you some more results.");
                    List<Attachment> attachments = new List<Attachment>();
                    attachments = await SearchMoreDataAsync(this.query);
                    if (attachments.Count > 0)
                    {
                        var reply = context.MakeMessage();
                        reply.Text = "Here is some more search results...";
                        reply.Attachments = attachments;
                        reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                        await context.PostAsync(reply);

                        var replyNext = context.MakeMessage();
                        replyNext.Text = "Does this help ?";
                        CardAction actionYes = new CardAction()
                        {
                            DisplayText = "YES",
                            Text = "YES",
                            Value = "YES",
                            Title = "YES",
                            Type = ActionTypes.ImBack
                        };
                        CardAction actionNo = new CardAction()
                        {
                            DisplayText = "NO",
                            Text = "NO",
                            Value = "NO",
                            Title = "NO",
                            Type = ActionTypes.ImBack
                        };
                        List<CardAction> cardActions = new List<CardAction>();
                        cardActions.Add(actionYes);
                        cardActions.Add(actionNo);
                        SuggestedActions suggestedActions = new SuggestedActions()
                        {
                            Actions = cardActions
                        };
                        replyNext.SuggestedActions = suggestedActions;
                        await context.PostAsync(replyNext);

                        context.Wait(this.CheckIfResultWorked);
                    }
                    else
                    {
                        await context.PostAsync("Sorry! Not able to find any more relevant data. I have registered your query to the support team. They will get back to you shortly");
                        context.Done<string>("DoneFromIPSDialog");
                    }
                }
                else
                {
                    await context.PostAsync("Sorry to hear that. I have registered your query " +
                        "with our support desk. They will get back to you shortly.");
                    context.Done<string>("DoneFromIPSDialog");
                }

            }
            else
            {
                var newMessage = context.MakeMessage();
                newMessage.Text = message.Text;
                await context.Forward(new BasicLuisDialog(this.userEmail), this.ResumeAfterNextDialog, newMessage, CancellationToken.None);
            }
        }

        private async Task ResumeAfterNextDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Done<string>("DoneFromIPSDialog");
        }

        private async Task<List<Attachment>> SearchDataAsync(string _query)
        {
            SearchHelper helper = new SearchHelper();
            List<IPSSearchValue> ipsSearchResult = new List<IPSSearchValue>();
            ipsSearchResult = helper.IPSSearchData(_query);

            List<Attachment> attachments = new List<Attachment>();

            for (int i = 0; i < 5; i++)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new TextBlock()
                {
                    Text = "Category : " + ipsSearchResult[i].Category
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "SubCategory : " + ipsSearchResult[i].SubCategory
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "Application : " + ipsSearchResult[i].Application
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "[Click Here](" + ipsSearchResult[i].Links + ")"
                });

                Attachment attachment = new Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                attachments.Add(attachment);

            }

            return attachments;
        }

        private async Task<List<Attachment>> SearchMoreDataAsync(string _query)
        {
            SearchHelper helper = new SearchHelper();
            List<IPSSearchValue> ipsSearchResult = new List<IPSSearchValue>();
            ipsSearchResult = helper.IPSSearchData(_query);

            List<Attachment> attachments = new List<Attachment>();
            int limit = 0;
            if(ipsSearchResult.Count > 10)
            {
                limit = 10;
            }
            else
            {
                limit = ipsSearchResult.Count;
            }
            for (int i = 5; i < limit; i++)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new TextBlock()
                {
                    Text = "Category : " + ipsSearchResult[i].Category
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "SubCategory : " + ipsSearchResult[i].SubCategory
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "Application : " + ipsSearchResult[i].Application
                });
                card.Body.Add(new TextBlock()
                {
                    Text = "[Click Here](" + ipsSearchResult[i].Links + ")"
                });

                Attachment attachment = new Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                attachments.Add(attachment);

            }

            return attachments;
        }
    }
}