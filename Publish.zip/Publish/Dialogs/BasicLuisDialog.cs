using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AdaptiveCards;
using LuisBot.Cards;
//using LuisBot.DataModel;
//using LuisBot.LuisModel;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;

namespace Microsoft.Bot.Sample.LuisBot
{
    // For more information about this template visit http://aka.ms/azurebots-csharp-luis
    [Serializable]
    public class BasicLuisDialog : LuisDialog<object>
    {
        private string userEmail = null;
        //public BasicLuisDialog() : base(new LuisService(new LuisModelAttribute(
        //    ConfigurationManager.AppSettings["LuisAppId"], 
        //    ConfigurationManager.AppSettings["LuisAPIKey"], 
        //    domain: ConfigurationManager.AppSettings["LuisAPIHostName"])))
        //{
        //}
        public BasicLuisDialog(string _uEmail) : base(new LuisService(new LuisModelAttribute(
            "44e0a82c-4e8d-4d25-9ed2-a42e749f131c",
            "90b712326ca644198f0bd3392a0d6b84",
            domain: "westus.api.cognitive.microsoft.com")))
        {
            this.userEmail = _uEmail;
        }

        [LuisIntent("None")]
        public async Task NoneIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            await this.NoneIntentResult(context, activity, result);
        }
        private async Task NoneIntentResult(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var message = await activity as Activity;
            await context.PostAsync("Opps! Seems I dont have any information regarding this query. \nPlease write to Support.ipsbot@volvo.com for the same.");
            await this.SendMail();
            context.Wait(MessageReceived);
        }

        [LuisIntent("Greeting")]
        public async Task GreetingIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.5)
            {
                await context.PostAsync("Hello there! Greetings of the day!! How may I assist you today?");
                context.Wait(MessageReceived);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("Cancel")]
        public async Task CancelIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.5)
            {
                await context.PostAsync("OK. I will stop. Hope to talk to you soon");
                context.Wait(MessageReceived);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("Help")]
        public async Task HelpIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.5)
            {
                var replyWithCard = context.MakeMessage();
                replyWithCard.Text = "Sure! I can help you with the follwing things";
                AdaptiveCard card = new AdaptiveCard();
                CardHelper cardHelper = new CardHelper();
                card = cardHelper.GetProactiveCard();
                Attachment attachment = new Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                replyWithCard.Attachments.Add(attachment);
                await context.PostAsync(replyWithCard);
                context.Wait(MessageReceived);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }

        }


        [LuisIntent("ToolsforRequesters")]
        public async Task ToolsForRequestersIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.5)
            {
                AdaptiveCard card = new AdaptiveCard();
                if (result.Query.ToUpper().Contains("EBD"))
                {
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[EBD](http://eprocure.nap.volvo.net/site/)",
                        Weight = TextWeight.Bolder
                    });
                }
                else if (result.Query.ToUpper().Contains("GPS"))
                {
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[GPS](http://teamplace.volvo.com/sites/PUsytemsAP/GPS/default.aspx)",
                        Weight = TextWeight.Bolder
                    });
                }
                else if (result.Query.ToUpper().Contains("VESA"))
                {
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[VESA](https://teamplace.volvo.com/sites/nap-support/esourcing/default.aspx)",
                        Weight = TextWeight.Bolder
                    });
                }
                else if (result.Query.ToUpper().Contains("SURPLUS"))
                {
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[Surplus Portal](https://teamplace.volvo.com/sites/nap-mro/sass/fr/default.aspx)",
                        Weight = TextWeight.Bolder
                    });
                }
                else if (result.Query.ToUpper().Contains("Fieldglass"))
                {
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[SAP VMS Fieldglass](https://www.fieldglass.eu/login.jsp?message=error.sso.notAuthorized)",
                        Weight = TextWeight.Bolder
                    });
                }
                else
                {
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[EBD](http://eprocure.nap.volvo.net/site/)",
                        Weight = TextWeight.Bolder
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[GPS](http://teamplace.volvo.com/sites/PUsytemsAP/GPS/default.aspx)",
                        Weight = TextWeight.Bolder
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[VESA](https://teamplace.volvo.com/sites/nap-support/esourcing/default.aspx)",
                        Weight = TextWeight.Bolder
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[Surplus Portal](https://teamplace.volvo.com/sites/nap-mro/sass/fr/default.aspx)",
                        Weight = TextWeight.Bolder
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[SAP VMS Fieldglass](https://www.fieldglass.eu/login.jsp?message=error.sso.notAuthorized)",
                        Weight = TextWeight.Bolder
                    });


                }
                Attachment attachment = new Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                var replyTyping = context.MakeMessage();
                replyTyping.Type = ActivityTypes.Typing;
                await context.PostAsync(replyTyping);
                await Task.Delay(2000);
                var reply = context.MakeMessage();
                reply.Text = "Please find the link :";
                reply.Attachments.Add(attachment);
                await context.PostAsync(reply);
                replyTyping.Type = ActivityTypes.Typing;
                await context.PostAsync(replyTyping);
                await Task.Delay(2000);
                //await context.PostAsync("Please let me know how may I help you further");
                context.Wait(this.MessageReceived);

            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("Acknowledgement")]
        public async Task AcknowledgementIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.5)
            {
                await context.PostAsync("Happy to help! Thank you for contacting IPS Chat Bot");
                context.Wait(MessageReceived);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("IPS")]
        public async Task IPSIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.3)
            {
                await this.IPSIntentResult(context, activity, result);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
        }

        [LuisIntent("QnA")]
        public async Task QnAIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            if (result.TopScoringIntent.Score > 0.3)
            {
                await this.QnAIntentResult(context, activity, result);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }
            

        }

        [LuisIntent("GenericQuestion")]
        public async Task GenericQuestionIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            AdaptiveCard card = new AdaptiveCard();

            if (result.TopScoringIntent.Score > 0.5)
            {
                if (result.Query.ToLower().Contains("how to buy") || result.Query.ToLower().Contains("h2b") || result.Query.ToLower().Contains("how2buy") || result.Query.ToLower().Contains("how2buy"))
                {
                    card.Body.Add(new TextBlock()
                    {
                        Text = "What is How2Buy ?",
                        Weight = TextWeight.Bolder,
                        Wrap = true
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "- It is an application that provides contact details, " +
                        "purchasing policies  and all other related information for different segments and commodities in IPS portfolio.",
                        Wrap = true
                    });
                }
                else if (result.Query.ToLower().Contains("ips"))
                {
                    card.Body.Add(new TextBlock()
                    {
                        Text = "What is IPS+ ?",
                        Weight = TextWeight.Bolder,
                        Wrap = true
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "- It is a one stop shop for finding all links related to Indirect Products and Services portfolio.",
                        Wrap = true
                    });
                }
                Attachment attachment = new Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                var reply = context.MakeMessage();
                reply.Attachments.Add(attachment);
                await context.PostAsync(reply);
                context.Wait(MessageReceived);
            }
            else
            {
                await this.NoneIntentResult(context, activity, result);
            }

        }

        private async Task IPSIntentResult(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            context.Call(new IPSDialog(result.Query.ToString(), this.userEmail), this.ResumeAfterNextDialog);
        }

        private async Task QnAIntentResult(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            string query = result.Query.ToString();
            string country = null;
            foreach (var item in result.Entities)
            {
                if (item.Type == "Country")
                {
                    country = item.Entity.ToString();
                }
            }
                
            context.Call(new HowToBuyDialog(query, country, this.userEmail), this.ResumeAfterNextDialog);
        }

        private async Task ResumeAfterNextDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Wait(MessageReceived);
        }

        public async Task SendMail()
        {
            //write the code of the mail
        }

       
    }
}