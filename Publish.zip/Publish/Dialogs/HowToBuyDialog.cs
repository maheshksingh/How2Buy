﻿using AdaptiveCards;
using LuisBot;
using LuisBot.Cards;
using LuisBot.SearchHelper;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Text;

namespace Microsoft.Bot.Sample.LuisBot
{
    [Serializable]
    public class HowToBuyDialog : IDialog<object>
    {
        private string userEmail = null;
        private string query;
        private string country;
        private int repeatCounter = 0;
        private string lang = null;
        public HowToBuyDialog(string _query, string _country, string _userEmail, string _lang)
        {
            this.query = _query;
            this.country = _country;
            this.userEmail = _userEmail;
            this.lang = _lang;
        }

        public async Task StartAsync(IDialogContext context)
        {
            if (this.country == null)
            {
                CardHelper getCard = new CardHelper();
                AdaptiveCard card = new AdaptiveCard();
                card = await getCard.GetCountrycard(this.lang);
                Connector.Attachment attachment = new Connector.Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                var replyTyping = context.MakeMessage();
                replyTyping.Type = ActivityTypes.Typing;
                await context.PostAsync(replyTyping);

                await Task.Delay(2000);

                var reply = context.MakeMessage();
                reply.Attachments.Add(attachment);
                await context.PostAsync(reply);
                context.Wait(this.MessageReceivedAsync);
            }
            else
            {
                List<Connector.Attachment> attachments = new List<Connector.Attachment>();
                attachments = await SearchDataAsync(this.query, this.country);

                if (attachments.Count > 0)
                {
                    if(this.lang != "en")
                    {
                        var reply = context.MakeMessage();
                        reply.Text = await this.Translate("Here is your search results...", this.lang);
                        reply.Attachments = attachments;
                        reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                        await context.PostAsync(reply);

                        var replyNext = context.MakeMessage();
                        replyNext.Text = await this.Translate("Does that help ?", this.lang);
                        CardAction actionYes = new CardAction()
                        {
                            DisplayText = await this.Translate("YES", this.lang),
                            Text = await this.Translate("YES", this.lang),
                            Value = await this.Translate("YES", this.lang),
                            Title = await this.Translate("YES", this.lang),
                            Type = ActionTypes.ImBack
                        };
                        CardAction actionNo = new CardAction()
                        {
                            DisplayText = await this.Translate("NO",this.lang),
                            Text = await this.Translate("NO", this.lang),
                            Value = await this.Translate("NO", this.lang),
                            Title = await this.Translate("NO", this.lang),
                            Type = ActionTypes.ImBack
                        };
                        List<CardAction> cardActions = new List<CardAction>();
                        cardActions.Add(actionYes);
                        cardActions.Add(actionNo);
                        SuggestedActions suggestedActions = new SuggestedActions()
                        {
                            Actions = cardActions
                        };
                        replyNext.SuggestedActions = suggestedActions;
                        await context.PostAsync(replyNext);
                    }
                    else
                    {
                        var reply = context.MakeMessage();
                        reply.Text = "Here is your search results...";
                        reply.Attachments = attachments;
                        reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                        await context.PostAsync(reply);

                        var replyNext = context.MakeMessage();
                        replyNext.Text = "Does that help ?";
                        CardAction actionYes = new CardAction()
                        {
                            DisplayText = "YES",
                            Text = "YES",
                            Value = "YES",
                            Title = "YES",
                            Type = ActionTypes.ImBack
                        };
                        CardAction actionNo = new CardAction()
                        {
                            DisplayText = "NO",
                            Text = "NO",
                            Value = "NO",
                            Title = "NO",
                            Type = ActionTypes.ImBack
                        };
                        List<CardAction> cardActions = new List<CardAction>();
                        cardActions.Add(actionYes);
                        cardActions.Add(actionNo);
                        SuggestedActions suggestedActions = new SuggestedActions()
                        {
                            Actions = cardActions
                        };
                        replyNext.SuggestedActions = suggestedActions;
                        await context.PostAsync(replyNext);
                    }
                    

                    context.Wait(this.CheckIfResultWorked);
                }
                else
                {
                    await this.SendEmail(this.query, this.userEmail);
                    if (this.lang != "en")
                    {
                        await context.PostAsync(await this.Translate("Sorry! Not able to find any relevant data. " +
                       "I have registered your query to the support team. They will get back to you shortly", this.lang));
                    }
                    else
                    {
                        await context.PostAsync("Sorry! Not able to find any relevant data. " +
                       "I have registered your query to the support team. They will get back to you shortly");
                    }
                    context.Done<string>("DoneFromHowToBuyDialog");
                }
            }
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;
            if (message.Value != null)
            {
                dynamic value = message.Value;
                if (value.Type == "Country")
                {
                    this.country = value.Country;
                    this.query = this.query + " in " + this.country;

                    List<Connector.Attachment> attachments = new List<Connector.Attachment>();
                    attachments = await SearchDataAsync(this.query, this.country);
                    if (attachments.Count > 0)
                    {
                        if (this.lang != "en")
                        {
                            var reply = context.MakeMessage();
                            reply.Text = await this.Translate("Here is your search results...", this.lang);
                            reply.Attachments = attachments;
                            reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                            await context.PostAsync(reply);

                            var replyNext = context.MakeMessage();
                            replyNext.Text = await this.Translate("Does that help ?", this.lang);
                            CardAction actionYes = new CardAction()
                            {
                                DisplayText = await this.Translate("YES", this.lang),
                                Text = await this.Translate("YES", this.lang),
                                Value = await this.Translate("YES", this.lang),
                                Title = await this.Translate("YES", this.lang),
                                Type = ActionTypes.ImBack
                            };
                            CardAction actionNo = new CardAction()
                            {
                                DisplayText = await this.Translate("NO", this.lang),
                                Text = await this.Translate("NO", this.lang),
                                Value = await this.Translate("NO", this.lang),
                                Title = await this.Translate("NO", this.lang),
                                Type = ActionTypes.ImBack
                            };
                            List<CardAction> cardActions = new List<CardAction>();
                            cardActions.Add(actionYes);
                            cardActions.Add(actionNo);
                            SuggestedActions suggestedActions = new SuggestedActions()
                            {
                                Actions = cardActions
                            };
                            replyNext.SuggestedActions = suggestedActions;
                            await context.PostAsync(replyNext);
                        }
                        else
                        {
                            var reply = context.MakeMessage();
                            reply.Text = "Here is your search results...";
                            reply.Attachments = attachments;
                            reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                            await context.PostAsync(reply);

                            var replyNext = context.MakeMessage();
                            replyNext.Text = "Does it help ?";
                            CardAction actionYes = new CardAction()
                            {
                                DisplayText = "YES",
                                Text = "YES",
                                Value = "YES",
                                Title = "YES",
                                Type = ActionTypes.ImBack
                            };
                            CardAction actionNo = new CardAction()
                            {
                                DisplayText = "NO",
                                Text = "NO",
                                Value = "NO",
                                Title = "NO",
                                Type = ActionTypes.ImBack
                            };
                            List<CardAction> cardActions = new List<CardAction>();
                            cardActions.Add(actionYes);
                            cardActions.Add(actionNo);
                            SuggestedActions suggestedActions = new SuggestedActions()
                            {
                                Actions = cardActions
                            };
                            replyNext.SuggestedActions = suggestedActions;
                            await context.PostAsync(replyNext);
                        }
                        context.Wait(this.CheckIfResultWorked);
                    }
                    else
                    {
                        await this.SendEmail(this.query, this.userEmail);
                        if (this.lang != "en")
                        {
                            await context.PostAsync(await this.Translate("Sorry! Not able to find any relevant data. " +
                           "I have registered your query to the support team.", this.lang));
                        }
                        else
                        {
                            await context.PostAsync("Sorry! Not able to find any relevant data. " +
                           "I have registered your query to the support team.");
                        }
                        context.Done<string>("DoneFromHowToBuyDialog");
                    }
                    
                }
                else
                {
                    AdaptiveCard card = new AdaptiveCard();
                    CardHelper getCard = new CardHelper();
                    card = await getCard.GetCountrycard(this.lang);

                    Connector.Attachment attachment = new Connector.Attachment()
                    {
                        Content = card,
                        ContentType = AdaptiveCard.ContentType
                    };
                    //typing
                    var replyTyping = context.MakeMessage();
                    replyTyping.Type = ActivityTypes.Typing;
                    await context.PostAsync(replyTyping);
                    await Task.Delay(2000);
                    var reply = context.MakeMessage();
                    if (this.lang != "en")
                    {
                        reply.Text = await this.Translate("Fields are mandatory. \n\n Please choose the country from the list below.", this.lang);
                    }
                    else
                    {
                        reply.Text = "Fields are mandatory. \n\n Please choose the country from the list below.";
                    }
                        
                    reply.Attachments.Add(attachment);
                    await context.PostAsync(reply);
                    context.Wait(this.MessageReceivedAsync);
                }
            }
            else
            {
                AdaptiveCard card = new AdaptiveCard();
                CardHelper getCard = new CardHelper();
                card = await getCard.GetCountrycard(this.lang);

                Connector.Attachment attachment = new Connector.Attachment()
                {
                    Content = card,
                    ContentType = AdaptiveCard.ContentType
                };
                //typing
                var replyTyping = context.MakeMessage();
                replyTyping.Type = ActivityTypes.Typing;
                await context.PostAsync(replyTyping);
                await Task.Delay(2000);

                var reply = context.MakeMessage();
                if (this.lang != "en")
                {
                    reply.Text = await this.Translate("Fields are mandatory. \n\n Please choose the country from the list below.", this.lang);
                }
                else
                {
                    reply.Text = "Fields are mandatory. \n\n Please choose the country from the list below.";
                }
                reply.Attachments.Add(attachment);
                await context.PostAsync(reply);
                context.Wait(this.MessageReceivedAsync);
            }

        }

        private async Task CheckIfResultWorked(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;

            var messageText = await this.Translate(message.Text, "en");

            if(messageText.ToUpper().Contains("YES"))
            {
                if (this.lang != "en")
                {
                    await context.PostAsync(await this.Translate("Great! Happy to help!", this.lang));
                }
                else
                {
                    await context.PostAsync("Great! Happy to help !");
                }
                    
                context.Done<string>("DoneFromHowToBuyDialog");
            }
            else if(messageText.ToUpper().Contains("NO"))
            {
                this.repeatCounter++;
                if (this.repeatCounter < 2)
                {
                    if(this.lang != "en")
                    {
                        await context.PostAsync(await this.Translate("Ok then, let me show you some more results.", this.lang));
                        List<Connector.Attachment> attachments = new List<Connector.Attachment>();
                        attachments = await SearchMoreDataAsync(this.query, this.country);
                        if (attachments.Count > 0)
                        {
                            var reply = context.MakeMessage();
                            reply.Text = await this.Translate("Here is some more search results...", this.lang);
                            reply.Attachments = attachments;
                            reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                            await context.PostAsync(reply);

                            var replyNext = context.MakeMessage();
                            replyNext.Text = await this.Translate("Does it help ?", this.lang);
                            CardAction actionYes = new CardAction()
                            {
                                DisplayText = await this.Translate("YES", this.lang),
                                Text = await this.Translate("YES", this.lang),
                                Value = await this.Translate("YES", this.lang),
                                Title = await this.Translate("YES", this.lang),
                                Type = ActionTypes.ImBack
                            };
                            CardAction actionNo = new CardAction()
                            {
                                DisplayText = await this.Translate("NO", this.lang),
                                Text = await this.Translate("NO", this.lang),
                                Value = await this.Translate("NO", this.lang),
                                Title = await this.Translate("NO", this.lang),
                                Type = ActionTypes.ImBack
                            };
                            List<CardAction> cardActions = new List<CardAction>();
                            cardActions.Add(actionYes);
                            cardActions.Add(actionNo);
                            SuggestedActions suggestedActions = new SuggestedActions()
                            {
                                Actions = cardActions
                            };
                            replyNext.SuggestedActions = suggestedActions;
                            await context.PostAsync(replyNext);

                            context.Wait(this.CheckIfResultWorked);
                        }
                        else
                        {
                            //await this.SendEmail(this.query, this.userEmail);
                            await context.PostAsync(await this.Translate("Sorry! Not able to find any more relevant data. " +
                                "I have registered your query to the support team.", this.lang));
                            context.Done<string>("DoneFromHowToBuyDialog");
                        }
                    }
                    else
                    {
                        await context.PostAsync("Ok ,let me show you some more results.");
                        List<Connector.Attachment> attachments = new List<Connector.Attachment>();
                        attachments = await SearchMoreDataAsync(this.query, this.country);
                        if (attachments.Count > 0)
                        {
                            var reply = context.MakeMessage();
                            reply.Text = "Please find more search results below..";
                            reply.Attachments = attachments;
                            reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                            await context.PostAsync(reply);

                            var replyNext = context.MakeMessage();
                            replyNext.Text = "Does it help ?";
                            CardAction actionYes = new CardAction()
                            {
                                DisplayText = "YES",
                                Text = "YES",
                                Value = "YES",
                                Title = "YES",
                                Type = ActionTypes.ImBack
                            };
                            CardAction actionNo = new CardAction()
                            {
                                DisplayText = "NO",
                                Text = "NO",
                                Value = "NO",
                                Title = "NO",
                                Type = ActionTypes.ImBack
                            };
                            List<CardAction> cardActions = new List<CardAction>();
                            cardActions.Add(actionYes);
                            cardActions.Add(actionNo);
                            SuggestedActions suggestedActions = new SuggestedActions()
                            {
                                Actions = cardActions
                            };
                            replyNext.SuggestedActions = suggestedActions;
                            await context.PostAsync(replyNext);

                            context.Wait(this.CheckIfResultWorked);
                        }
                        else
                        {
                            //await this.SendEmail(this.query, this.userEmail);
                            await context.PostAsync("Sorry! Not able to find any relevant data. " +
                                "I have registered your query to the support team.");
                            context.Done<string>("DoneFromHowToBuyDialog");
                        }
                    }
                    
                }
                else
                {
                    await this.SendEmail(this.query, this.userEmail);
                    if (this.lang != "en")
                    {
                        await context.PostAsync(await this.Translate("Sorry to hear that. I have registered your query " +
                        "with our support desk.", this.lang));
                    }
                    else
                    {
                        await context.PostAsync("Sorry to hear that. I have registered your query " +
                        "with our support desk.");
                    }
                        
                    context.Done<string>("DoneFromHowToBuyDialog");
                }
                
            }
            else
            {
                var translatorClient = new TranslatorService.TranslatorClient("8c51979522cf43c38d67847add69b2d9");
                var trasnlatedText = await translatorClient.TranslateAsync(message.Text, "en");

                var newMessage = context.MakeMessage();
                newMessage.Text = trasnlatedText.Translation.Text;
                newMessage.Locale = trasnlatedText.DetectedLanguage.Language;
                await context.Forward(new BasicLuisDialog(this.userEmail), this.ResumeAfterNextDialog, newMessage, CancellationToken.None);
            }
        }

        private async Task ResumeAfterNextDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Done<string>("DoneFromHowToBuyDialog");
        }

        private async Task<List<Connector.Attachment>> SearchDataAsync(string _query, string country)
        {
            SearchHelper helper = new SearchHelper();
            List<H2BSearchValue> h2BSearchResult = new List<H2BSearchValue>();
            h2BSearchResult = helper.H2BSearchData(_query);

            List<Connector.Attachment> attachments = new List<Connector.Attachment>();
            
            for(int i = 0; i < 2; i++)
            {
                if(h2BSearchResult[i].Country.ToUpper() == country.ToUpper())
                {
                    AdaptiveCard card = new AdaptiveCard();
                    card.Body.Add(new TextBlock()
                    {
                        Text = "Commodity : " + h2BSearchResult[i].IPS_COMMODITY
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "Segment : " + h2BSearchResult[i].SEGMENT
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "Country : " + h2BSearchResult[i].Country
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[Click Here](" + h2BSearchResult[i].Link + ")"
                    });

                    Connector.Attachment attachment = new Connector.Attachment()
                    {
                        Content = card,
                        ContentType = AdaptiveCard.ContentType
                    };
                    attachments.Add(attachment);
                }
                
            }

            return attachments;
        }

        private async Task<List<Connector.Attachment>> SearchMoreDataAsync(string _query, string country)
        {
            SearchHelper helper = new SearchHelper();
            List<H2BSearchValue> h2BSearchResult = new List<H2BSearchValue>();
            h2BSearchResult = helper.H2BSearchData(_query);

            List<Connector.Attachment> attachments = new List<Connector.Attachment>();

            for (int i = 2; i < 5; i++)
            {
                if (h2BSearchResult[i].Country.ToUpper() == country.ToUpper())
                {
                    AdaptiveCard card = new AdaptiveCard();
                    card.Body.Add(new TextBlock()
                    {
                        Text = "Commodity : " + h2BSearchResult[i].IPS_COMMODITY
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "Segment : " + h2BSearchResult[i].SEGMENT
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "Country : " + h2BSearchResult[i].Country
                    });
                    card.Body.Add(new TextBlock()
                    {
                        Text = "[Click Here](" + h2BSearchResult[i].Link + ")"
                    });

                    Connector.Attachment attachment = new Connector.Attachment()
                    {
                        Content = card,
                        ContentType = AdaptiveCard.ContentType
                    };
                    attachments.Add(attachment);
                }
            }

            return attachments;
        }

        private async Task SendEmail(string query, string toEmail)
        {

            StringBuilder strHtml = new StringBuilder();

            strHtml.Append("</head>\n");
            strHtml.Append("<body  bgcolor=\"#ffffff\">\n");

            strHtml.Append("<table style=\"font-family:calibri;\" width=\"100%\" height=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n");
            strHtml.Append("<tr>\n");
            //strHtml.Append("<td class=\"bluebackground\">&nbsp;</td>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("<div class=\"header2\">\n");
            strHtml.Append("<p style=\"border-style:solid; border-color:#566D7E;\">");
            strHtml.Append("<b>");
            strHtml.Append("Regarding Un-Answered Queries from BOB \n");
            strHtml.Append("</b>");
            strHtml.Append("</div>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("<b>");
            strHtml.Append("Following is the Unanswered Query: ");
            strHtml.Append("</b>");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("Query: " + query);
            strHtml.Append("</td>\n");

            strHtml.Append("<td>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");

            strHtml.Append("<td>\n");
            strHtml.Append("<br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td>\n");
            strHtml.Append("<br></br>\n");
            strHtml.Append("<br></br>\n");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");


            strHtml.Append("<tr>\n");
            strHtml.Append("<td class=\"content\">\n");
            strHtml.Append("Regards,");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("<tr>\n");
            strHtml.Append("<td>\n");
            strHtml.Append("BOB - The IPS Chatbot");
            strHtml.Append("</td>\n");
            strHtml.Append("</tr>\n");

            strHtml.Append("</table>\n");
            strHtml.Append("</body>\n");
            strHtml.Append("</html>\n");



            string msgSenderEmail = string.Empty;
            string msgRecipient = string.Empty;
            string smtpServer = string.Empty;

            MailMessage mail = new MailMessage();

            msgSenderEmail = "Support.ipsbot@volvo.com";
            msgRecipient = toEmail;
            smtpServer = "mailgot.it.volvo.com";
            mail.From = new MailAddress(msgSenderEmail);
            mail.To.Add(msgRecipient);
            mail.Subject = "Reg: BOB Unresolved Query";
            mail.Body = strHtml.ToString() ;
            mail.IsBodyHtml = true;

            SmtpClient SmtpServer = new SmtpClient(smtpServer);

            SmtpServer.Send(mail);

        }

        private async Task<string> Translate(string text, string toLang)
        {
            string result = null;
            var translatorClient = new TranslatorService.TranslatorClient("8c51979522cf43c38d67847add69b2d9");
            var languageDetected = translatorClient.DetectLanguageAsync(text);
            var trasnlatedText = await translatorClient.TranslateAsync(text, toLang);
            result = trasnlatedText.Translation.Text;
            return result;
        }
    }
}