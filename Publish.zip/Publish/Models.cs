﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LuisBot
{
    //public class How2BuySearchDataModel
    //{
    //    public string odatacontext { get; set; }
    //    public H2BValue[] value { get; set; }
    //    public string odatanextLink { get; set; }
    //}

    public class H2BSearchValue
    {
        public double searchscore { get; set; }
        public string Id { get; set; }
        public string Country { get; set; }
        public string IPS_COMMODITY { get; set; }
        public string SEGMENT { get; set; }
        public string Link { get; set; }
    }


    //public class IPSSearchDataModel
    //{
    //    public string odatacontext { get; set; }
    //    public IPSValue[] value { get; set; }
    //}

    public class IPSSearchValue
    {
        public double searchscore { get; set; }
        public string ID { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string Application { get; set; }
        public string Links { get; set; }
    }


}