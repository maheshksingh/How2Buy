﻿using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace LuisBot.SearchHelper
{
    public class SearchHelper
    {
        public List<H2BSearchValue> H2BSearchData(string query)
        {
            DocumentSearchResult searchResult = new DocumentSearchResult();
            ISearchIndexClient indexClientForQueries = this.CreateH2BSearchIndexClient("azuresql-index");
            List<H2BSearchValue> h2BSearch = new List<H2BSearchValue>();
            searchResult = this.RunQueries(indexClientForQueries, query);
            foreach(var item in searchResult.Results)
            {
                H2BSearchValue h2BSearchValue = new H2BSearchValue();
                h2BSearchValue.searchscore = item.Score;
                h2BSearchValue.Id = item.Document["Id"].ToString();
                h2BSearchValue.Country = item.Document["Country"].ToString();
                h2BSearchValue.IPS_COMMODITY = item.Document["IPS_COMMODITY"].ToString();
                h2BSearchValue.SEGMENT = item.Document["SEGMENT"].ToString();
                h2BSearchValue.Link = item.Document["Link"].ToString();
                h2BSearch.Add(h2BSearchValue);
            }

            return h2BSearch;
        }

        public List<IPSSearchValue> IPSSearchData(string query)
        {
            DocumentSearchResult searchResult = new DocumentSearchResult();
            ISearchIndexClient indexClientForQueries = this.CreateH2BSearchIndexClient("ipstable-index");
            List<IPSSearchValue> ipsSearch = new List<IPSSearchValue>();
            searchResult = this.RunQueries(indexClientForQueries, query);
            foreach (var item in searchResult.Results)
            {
                IPSSearchValue ipsSearchValue = new IPSSearchValue();
                ipsSearchValue.searchscore = item.Score;
                ipsSearchValue.ID = item.Document["ID"].ToString();
                ipsSearchValue.Category = item.Document["Category"].ToString();
                ipsSearchValue.SubCategory = item.Document["SubCategory"].ToString();
                ipsSearchValue.Application = item.Document["Application"].ToString();
                ipsSearchValue.Links = item.Document["Links"].ToString();
                ipsSearch.Add(ipsSearchValue);
            }

            return ipsSearch;
        }
        private SearchServiceClient CreateSearchServiceClient()
        {
            string searchServiceName = "ipschatbotsearch";
            string adminApiKey = "658A276EEFC4D055DA3F388261A7F21C";

            SearchServiceClient serviceClient = new SearchServiceClient(searchServiceName, new SearchCredentials(adminApiKey));
            return serviceClient;
        }

        private SearchIndexClient CreateH2BSearchIndexClient(string indexName)
        {
            string searchServiceName = "ipschatbotsearch";
            string queryApiKey = "360470501E9A3C6530186FE93280E6D6";

            SearchIndexClient indexClient = new SearchIndexClient(searchServiceName, indexName, new SearchCredentials(queryApiKey));
            return indexClient;
        }

        private DocumentSearchResult RunQueries(ISearchIndexClient indexClient, string query)
        {
            DocumentSearchResult results = new DocumentSearchResult();
            results = indexClient.Documents.Search(query);
            return results;
        }
    }
}