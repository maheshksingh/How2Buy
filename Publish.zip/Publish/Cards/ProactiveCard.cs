﻿using AdaptiveCards;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LuisBot.Cards
{
    public partial class CardHelper
    {
        public AdaptiveCard GetProactiveCard()
        {
            AdaptiveCard card = new AdaptiveCard();

            card.Actions.Add(new SubmitAction()
            {
                Data = "How2Buy",
                Title = "HOW2BUY(Quick Search)"
            });
            card.Body.Add(new TextBlock()
            {
                Text = "How2Buy",
                Weight = TextWeight.Bolder,
                Size = TextSize.Medium,
                Wrap = true
            });
            card.Body.Add(new TextBlock()
            {
                Text = "- It is an application that provides contact details, " +
                "purchasing policies  and all other related information for different segments and commodities in IPS portfolio.",
                Wrap = true
            });
            card.Actions.Add(new SubmitAction()
            {
                Data = "IPS+",
                Title = "IPS+"
            });
            card.Body.Add(new TextBlock()
            {
                Text = "IPS+",
                Weight = TextWeight.Bolder,
                Size = TextSize.Medium,
                Wrap = true
            });
            card.Body.Add(new TextBlock()
            {
                Text = "- It is a one stop shop for finding all links related to Indirect Products and Services portfolio.",
                Wrap = true
            });

            return card;
        }
    }
}