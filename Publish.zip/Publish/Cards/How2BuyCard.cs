﻿using AdaptiveCards;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Resources;
using System.Web;
using System.Reflection;
using System.Globalization;
using System.Collections;

namespace LuisBot.Cards
{
    public partial class CardHelper
    {
        public AdaptiveCard GetCountrycard()
        {
            AdaptiveCard card = new AdaptiveCard();
            List<string> CountryChoices = new List<string>();
            CountryChoices = this.GetCountryChoiceList();
            if (CountryChoices.Count > 0)
            {
                List<Choice> adaptiveChoicesCountry = new List<Choice>();
                foreach (var item in CountryChoices)
                {
                    adaptiveChoicesCountry.Add(new Choice()
                    {
                        Title = item.ToString(),
                        Value = item.ToString(),
                    });
                }
                card.Body.Add(new TextBlock()
                {
                    Text = "Please selet the Country",
                    Weight = TextWeight.Bolder,
                    Size = TextSize.Normal
                });
                card.Body.Add(new ChoiceSet()
                {
                    Id = "Country",
                    Style = ChoiceInputStyle.Compact,
                    IsMultiSelect = false,
                    Choices = adaptiveChoicesCountry
                });
                card.Actions.Add(new SubmitAction()
                {
                    Title = "Search",
                    DataJson = "{\"Type\": \"Country\" }"
                });
                return card;
            }
            else
            {
                return null;
            }
        }

        private List<string> GetCountryChoiceList()
        {
            List<string> countryList = new List<string>();
            //using (var dbContext = new ChatBotDBEntities())
            //{
            //    countryList = dbContext.H2BQuickSearchData.Select(d => d.Country).Distinct().ToList();
            //}
            countryList.Add("Finland");
            countryList.Add("South Korea");
            countryList.Add("USA");
            countryList.Add("Brazil");
            countryList.Add("Malaysia");
            countryList.Add("Indonesia");
            countryList.Add("Germany");
            countryList.Add("Australia");
            countryList.Add("Mexico");
            countryList.Add("Sweden");
            countryList.Add("Great Britain");
            countryList.Add("China");
            countryList.Add("Peru");
            countryList.Add("India");
            countryList.Add("Russia");
            countryList.Add("Poland");
            countryList.Add("Canada");
            countryList.Add("Thailand");
            countryList.Add("France");
            countryList.Add("Belgium");
            countryList.Add("Japan");
            countryList.Add("Singapore");
            countryList.Add("Chile");
            countryList.Add("South Africa");

            return countryList;
        }
    }
}